const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const ROOT = path.resolve(__dirname, "..");

test("manifest does not pin an extension key", () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));

  assert.equal(Object.prototype.hasOwnProperty.call(manifest, "key"), false);
});

test("interactive auth chooses popup monitoring when the configured redirect differs from chrome.identity", () => {
  const appSource = fs.readFileSync(path.join(ROOT, "app.js"), "utf8");
  const hydrationSectionMatch = appSource.match(
    /async function attemptSessionHydration\([\s\S]*?\n}\n\nfunction requireConfiguredClientId/
  );

  assert.ok(hydrationSectionMatch, "attemptSessionHydration should exist");
  const hydrationSection = hydrationSectionMatch[0];

  assert.match(hydrationSection, /const authTransport = interactive && !shouldUseChromeIdentityRedirectTransport\(redirectUri\)/);
  assert.match(hydrationSection, /transport: authTransport/);
  assert.match(hydrationSection, /callbackUrl = await launchInteractiveAuthPopup\(\{/);
  assert.match(hydrationSection, /callbackUrl = await chrome\.identity\.launchWebAuthFlow\(launchDetails\);/);
});

test("popup-monitor auth captures redirects from webNavigation before Chrome swaps in an error page", () => {
  const appSource = fs.readFileSync(path.join(ROOT, "app.js"), "utf8");
  const popupSectionMatch = appSource.match(
    /async function launchInteractiveAuthPopup\([\s\S]*?\n}\n\nasync function closeInteractiveAuthPopup/
  );

  assert.ok(popupSectionMatch, "launchInteractiveAuthPopup should exist");
  const popupSection = popupSectionMatch[0];

  assert.match(popupSection, /chrome\.webNavigation\?\.onBeforeNavigate/);
  assert.match(popupSection, /chrome\.webNavigation\.onBeforeNavigate\.addListener\(handleBeforeNavigate\)/);
  assert.match(popupSection, /chrome\.webNavigation\.onCommitted\.addListener\(handleCommitted\)/);
  assert.match(popupSection, /chrome\.webNavigation\.onErrorOccurred\.addListener\(handleNavigationError\)/);
  assert.match(popupSection, /Number\(details\?\.tabId \|\| 0\) !== popupTabId/);
  assert.match(popupSection, /return maybeCaptureRedirect\(details\?\.url\);/);
});

test("runtime config accepts the Adobe project export redirect URI", () => {
  const sharedSource = fs.readFileSync(path.join(ROOT, "shared.js"), "utf8");

  assert.match(sharedSource, /IMS_PROJECT_DEFAULT_EXTENSION_REDIRECT_URI = "https:\/\/danaegilocobhopoepodlpondjjfcpoi\.chromiumapp\.org\/ims"/);
  assert.match(sharedSource, /project\.workspace\.details\.credentials\.0\.oauth2\.client_id/);
  assert.match(sharedSource, /project\.workspace\.details\.credentials\.0\.oauth2\.defaultRedirectUri/);
  assert.match(sharedSource, /redirectUri,/);
});

test("scope planning still prefers org discovery when the configured scope lacks it", () => {
  const appSource = fs.readFileSync(path.join(ROOT, "app.js"), "utf8");
  const scopeSectionMatch = appSource.match(
    /function buildPreferredRequestedScope\([\s\S]*?\n}\n\nfunction shouldRetryWithConfiguredScope/
  );

  assert.ok(scopeSectionMatch, "scope planning helpers should exist");
  const scopeSection = scopeSectionMatch[0];

  assert.match(scopeSection, /scopeIncludes\(normalizedConfiguredScope, IMS_ORG_DISCOVERY_SCOPE\)/);
  assert.match(scopeSection, /return normalizeScopeList\(`\$\{normalizedConfiguredScope\} \$\{IMS_ORG_DISCOVERY_SCOPE\}`/);
  assert.match(scopeSection, /new Set\(\[preferredScope, normalizedConfiguredScope\]\)/);
});

test("manifest declares webNavigation for popup redirect capture", () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, "manifest.json"), "utf8"));

  assert.ok(Array.isArray(manifest.permissions), "manifest permissions should be an array");
  assert.ok(manifest.permissions.includes("webNavigation"));
});
